package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import pages.BasePage;
import pages.SignUpPage;

import java.util.concurrent.TimeUnit;

public class BaseTest {
    private WebDriver driver;
    private SignUpPage signUpPage;

    public WebDriver getDriver() {
        return driver;
    }

    public SignUpPage getSignUpPage() {
        return signUpPage;
    }

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C://Users//Natasa//Desktop//chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        signUpPage = new SignUpPage(driver);
    }

    @BeforeMethod
    public void beforeEachTest() {
        driver.get("https://vue-demo.daniel-avellaneda.com");
        driver.manage().window().maximize();
        WebElement signUp = driver.findElement(By.cssSelector("#app > div.v-application--wrap > div > header > div > div.v-toolbar__items > a:nth-child(4) > span"));
        signUp.click();
    }

    @AfterClass
    public void closeUp() {
        driver.close();
    }
}